setlocal ENABLEDELAYEDEXPANSION

set APP_NAME=cyberkingorderapptauri-pro.exe
REM Tên app rút gọn (KHÔNG .exe, KHÔNG quá dài)
set APP_KEY=cyberkingorderapptauri

REM Đợi app khởi động hoàn toàn
timeout /t 5 /nobreak >nul

:checkProcess
set FOUND=0

for /f "delims=" %%A in ('tasklist ^| findstr /I "%APP_KEY%"') do (
    set FOUND=1
)

if "%FOUND%"=="0" goto restartPC
else (
    timeout /t 180 /nobreak >nul
    goto checkProcess
)


:restartPC
timeout /t 60 /nobreak >nul
shutdown /r /t 0 /f