Set objShell = CreateObject("Scripting.FileSystemObject")
strScriptPath = WScript.ScriptFullName
strScriptDir = objShell.GetParentFolderName(strScriptPath)

strBatchFilePath = strScriptDir & "\startup.bat"

Set WshShell = CreateObject("WScript.Shell")

' Chạy lệnh cmd.exe để thực thi file batch ẩn
WshShell.Run "cmd.exe /c start /B """" """ & strBatchFilePath & """", 0, False